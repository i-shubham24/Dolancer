---
name: Dolancer V2
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#4a4455'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#732ee4'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#7d3d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a15100'
  on-tertiary-container: '#ffe0cd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb784'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  slate-50: '#f8fafc'
  slate-100: '#f1f5f9'
  slate-900: '#0f172a'
  violet-600: '#7c3aed'
  teal-500: '#14b8a6'
  rose-500: '#f43f5e'
typography:
  headline-xl:
    fontFamily: DM Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: DM Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: DM Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: DM Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system merges the aspirational energy of the creator economy with enterprise-grade reliability. The UI evokes confidence, trustworthiness, and fluid creativity through generous whitespace, soft diffused shadows, subtle pastel ambient gradients, and glass-morphic layers. We eschew harsh contrasts in favor of an exceptionally smooth, modern web application feel.

## Colors

The palette is anchored by a soft cool gray canvas (`slate-50`) designed to make pure white surfaces pop. Deep violet (`violet-600`) drives primary brand interactions, conveying both creative ambition and institutional trust. Teal (`teal-500`) and rose (`rose-500`) serve as functional accents for growth and alerts, while ambient background gradients introduce subtle depth without visual clutter.

## Typography

A dual-font system balances editorial personality with utilitarian legibility. `DM Sans` is employed for all headings, hero text, and numerical displays, bringing geometric warmth and modernity. `Inter` handles body copy, forms, tables, and buttons to ensure maximum clarity and scanning efficiency at smaller scales.

## Layout & Spacing

The layout utilizes a fluid grid framework paired with generous outer margins to maintain breathing room across all screen sizes. Marketing views employ full-bleed sections with bento-box feature grids, while authenticated app views feature a structured sidebar navigation and sticky headers with breadcrumbs. Maintain a strict 8px baseline rhythm for all internal component paddings and stack gaps.

## Elevation & Depth

Visual hierarchy relies on soft, diffused ambient shadows and tonal layering rather than harsh borders. Cards and floating containers utilize ultra-soft drop shadows (`shadow-[0_8px_30px_rgb(0,0,0,0.04)]`) paired with pure white surfaces against the cool gray canvas. Glass-morphic elements with backdrop blurs are reserved for sticky headers and floating navigation overlays.

## Shapes

The shape language prioritizes approachability and fluid modernism. Cards feature generous `rounded-2xl` corners, inputs use `rounded-xl` radii for a friendly yet structured feel, and interactive buttons adopt fully pill-shaped (`rounded-full`) geometries.

## Components

- **Buttons:** Rendered as pill shapes (`rounded-full`) with the primary violet fill. Incorporate a smooth vertical lift (`-translate-y-0.5`) and soft colored shadow on hover, utilizing spring physics for interactions.
- **Cards:** Pure white surfaces with `rounded-2xl` corners, ultra-soft drop shadows, and optional ultra-thin `slate-100` borders.
- **Inputs:** Styled with `rounded-xl` borders in soft gray that transition cleanly to solid primary violet upon focus, accompanied by a subtle focus ring.
- **Chips & Badges:** Compact elements featuring soft pastel background fills matched with darker semantic text colors for clear status signaling.
- **Lists & Tables:** Clean, high-legibility rows using `Inter` typography, subtle divider lines, and generous vertical padding to prevent cognitive overload.
- **Checkboxes & Radios:** Minimalist geometry with primary violet accent states and smooth transition animations.