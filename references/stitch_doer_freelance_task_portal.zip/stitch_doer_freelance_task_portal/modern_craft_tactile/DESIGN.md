---
name: Modern Craft Tactile
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#632ecd'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d4ce7'
  on-tertiary-container: '#f6edff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.011em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.006em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-energy, premium craft digital atelier tailored for high-output independent talent and top-tier clients. Rejecting both corporate sterility and abrasive brutalism, the identity embodies precision, momentum, and tangible execution. 

Key emotional responses:
- **Trust & Velocity:** Fluid financial assurances, immediate escrow clarity, and dynamic momentum.
- **Physicality & Tactility:** Surfaces evoke micro-embossing, polished resin chips, satin ceramic cards, and optical glass overlays that respond naturally to user intent.
- **Optimism & Distinction:** Crisp daylight foundations broken by electric accents, delivering high-definition vibrancy without eye strain.

The design movement merges **Modern Tactile UI** with **Frosted Optical Layering**. It pairs crisp daylight porcelain backdrops with electric cobalt, minted emerald escrow tiers, violet creative accents, and subtle prismatic rim highlights.

## Colors

The palette avoids heavy dark neutrals or washed-out grays in favor of an active, porcelain-and-cobalt framework with distinct semantic territories:

- **Primary Canvas & Surfaces:** Pure milk white (`#FFFFFF`) sits on subtle porcelain foundations (`#F8FAFC`), supported by slate structuring borders (`#E2E8F0`, `#CBD5E1`) and high-density slate-900 typography (`#0F172A`).
- **Primary Kinetic Accent (`#2563EB` / `#1D4ED8`):** Electric Cobalt signals core workflows, active proposals, and navigation triggers.
- **Escrow & Verified Capital (`#10B981` / `#059669`):** Emerald and mint designate released milestone funds, active escrows, authenticated identity ticks, and healthy deliverables.
- **Craft & Creative Prestige (`#8B5CF6` / `#7C3AED`):** Violet accents differentiate rare talent tiers, bespoke skill validations, and elite milestone badges.
- **Luminous Alert & Momentum (`#F59E0B`):** Warm amber highlights active counters, impending milestones, and live negotiation pings.
- **Iridescent Trims:** Ghost gradients (`linear-gradient(135deg, rgba(37,99,235,0.15), rgba(139,92,246,0.15))`) deliver dimensional edge definitions across high-priority glass layers.

## Typography

The typographic hierarchy balances expressive momentum with high-density data readability:

- **Display & Headlines (Plus Jakarta Sans):** Selected for its crisp geometric curves, subtle humanist apertures, and punchy editorial authority. Headlines employ tight negative tracking (`-0.01em` to `-0.03em`) to anchor dashboards and project portfolios.
- **Body & Data Reads (Inter):** Deployed for descriptions, contracts, milestone logs, and rates. The neutral tall x-height guarantees crisp parsing across varying resolutions.
- **Labels & Micro-Metrics (Plus Jakarta Sans):** Set at weights `600` and `700` with open tracking on badges, escrow tickers, and category tags to ensure clear scannability at small sizes.

## Layout & Spacing

The layout is built on a responsive 12-column dynamic fluid grid on desktop, scaling to 8 columns on tablet and 4 columns on mobile:

- **Canvas Alignment:** Desktop workspaces feature a maximum container constraint of `1440px` with fluid column widths, bounded by a `2rem` (`margin`) outer border.
- **Breakpoints:**
  - `Mobile (< 768px)`: 4 columns, `margin: 1rem`, `gutter: 1rem`. Bottom sheets replace modal sidebars.
  - `Tablet (768px - 1024px)`: 8 columns, `margin: 1.5rem`, `gutter: 1.25rem`. Two-column card splits.
  - `Desktop (> 1024px)`: 12 columns, `margin: 2rem`, `gutter: 1.5rem`. Multi-pane split layouts (escrow timeline, workspace preview, dynamic profile).
- **Rhythm Model:** Strict 4px/8px incremental spacing scale (`space-xs` through `space-xl`) governs internal padding, metadata pill clusters, and structural section splits.

## Elevation & Depth

Visual depth avoids dull charcoal drop-shadows, using multi-layered ambient light refraction and crisp edge rings:

1. **Ground Tier (Flat):** Base canvas in `#F8FAFC` without shadow; zones partitioned via hairline borders (`1px solid #E2E8F0`).
2. **Interactive Surface (Cards, Panels):** Pure `#FFFFFF` resting on a dual-layer micro-drop shadow:
   - `0 1px 3px rgba(15, 23, 42, 0.04), 0 4px 12px rgba(37, 99, 235, 0.04)`
   - Border: `1px solid rgba(226, 232, 240, 0.8)`
3. **Hover & Kinetic State:** Surfaces lift by `-2px`, dynamically expanding the ambient cast:
   - `0 12px 24px -4px rgba(37, 99, 235, 0.08), 0 4px 8px -2px rgba(15, 23, 42, 0.03)`
   - Border transitions to a vibrant gradient edge or `#93C5FD`.
4. **Floating Frosted Glass (Navbars, Sticky Headers, Escrow Summaries):**
   - Translucent backing: `backdrop-blur-md bg-white/80`
   - Perimeter highlight: `1px solid rgba(226, 232, 240, 0.7)` with an inner specular ring `inset 0 1px 0 rgba(255, 255, 255, 0.8)`.
5. **Overlays & Modals:**
   - Deep ambient diffusion: `0 24px 48px -12px rgba(15, 23, 42, 0.12), 0 8px 16px -4px rgba(37, 99, 235, 0.06)`.

## Shapes

The geometry balances structured utility with friendly, modern consumer craft:

- **Base Radius (`0.5rem` / `8px`):** Used on text inputs, utility buttons, dropdown menus, and standard table rows.
- **Large Radius (`rounded-lg` / `1rem` / `16px`):** Assigned to proposal cards, talent showcase modules, gig briefs, and escrow summary cards.
- **Extra-Large Radius (`rounded-xl` / `1.5rem` / `24px`):** Used for elevated flyouts, persistent workspace sheets, and hero banners.
- **Full Pill (`9999px`):** Applied strictly to tactile metadata tags, category filters, verification pills, and primary CTAs to create distinct interactive targets.

## Components

### Buttons & Interactive Triggers
- **Primary CTA:** Solid Electric Cobalt (`#2563EB`) with crisp white typography (`#FFFFFF`). Subtle top highlight (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`), gentle shadow (`0 2px 4px rgba(37, 99, 235, 0.2)`). Hover prompts active scaling (`translateY(-1px)`) and background shift to `#1D4ED8`.
- **Secondary Tactile:** Surface in `#FFFFFF` bordered with `#E2E8F0`, dark slate text (`#0F172A`). Hover activates `#F8FAFC` background with an emerald or cobalt-tinted border.
- **Escrow Action Button:** Vibrant Emerald (`#10B981`) base, white text, styled with micro-drop glow (`0 4px 14px rgba(16, 185, 129, 0.25)`).

### Tactile Pill Tags & Sleek Status Chips
- **Status Chips:** High-saturation translucent fills with crisp solid dots:
  - *Escrow Funded:* `bg-emerald-50 text-emerald-700 border border-emerald-200/60` with a pulsating 6px `#10B981` dot.
  - *In Review:* `bg-amber-50 text-amber-700 border border-amber-200/60`.
  - *Elite Talent:* `bg-violet-50 text-violet-700 border border-violet-200/60`.
- **Pill Tags:** Fully rounded (`rounded-full`), micro-padding (`px-3 py-1`), typography `label-sm`. Light gray backing (`#F1F5F9`) shifts to cobalt tint on selection.

### Cards & Talent Showcases
- **Structure:** Milk white container (`#FFFFFF`), `rounded-lg` (16px), subtle border (`#E2E8F0`).
- **Interactive State:** Hover triggers an optical shift—border deepens to dynamic cobalt-slate, subtle `-2px` Y-lift, and iridescent edge glow along the top boundary.

### Inputs & Search Fields
- **Container:** Background `#FFFFFF`, border `1.5px solid #CBD5E1`, typography `body-md`.
- **Focus State:** Border changes to `#2563EB`, paired with a crisp outer glow ring: `0 0 0 4px rgba(37, 99, 235, 0.12)`. No harsh browser outlines.

### Checkboxes & Radios
- **Geometry:** 20px squares (`rounded-md`) and circles. Unchecked: `#FFFFFF` with `#CBD5E1` border.
- **Checked:** Cobalt fill (`#2563EB`) housing a sharp white icon or dot, elevated by micro-inset lighting.

### Dynamic Progress Rings (Milestone & Payout Trackers)
- **Ring Presentation:** SVG circular meters using crisp tracks (`#E2E8F0`) alongside gradient stroke fills (`#2563EB` transitioning to `#10B981`). Center houses clear numeric values in `headline-sm` Plus Jakarta Sans.