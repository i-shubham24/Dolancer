# Dolancer Design System (V2)

## 1. Aesthetic Vision
**"Aspirational Creator Economy meets Enterprise Reliability"**

We are discarding the high-contrast, harsh Neo-Brutalism style. The new Dolancer will feel premium, incredibly smooth, and highly trustworthy. It will use generous whitespace, soft diffused shadows, subtle pastel ambient backgrounds, and glass-morphic elements for a cutting-edge, modern web application feel.

## 2. Typography
We use a two-font system to create editorial elegance while maintaining high UI legibility.
*   **Headings / Display:** `DM Sans` - Geometric, friendly, and modern. Used for page titles, hero text, and numbers.
*   **Body / UI:** `Inter` - Highly legible, neutral, and professional. Used for forms, tables, descriptions, and buttons.

## 3. Color Palette
*   **Background (Canvas):** Soft, cool gray (`#f8fafc` or `slate-50`) to make white cards pop.
*   **Surfaces:** Pure White (`#ffffff`) with subtle 1px borders (`slate-100`).
*   **Primary Brand:** Deep Violet / Indigo (e.g., `violet-600` `#7c3aed`). Conveys creativity and trust.
*   **Accents:** Teal (`teal-500`) for success/growth, Rose (`rose-500`) for danger/alerts.
*   **Ambient Gradients:** Very soft, large blurred circles in the background of marketing pages (e.g., `purple/10` and `blue/10` with `blur-3xl`).

## 4. Component DNA
*   **Cards:** `rounded-2xl`, pure white background, `shadow-[0_8px_30px_rgb(0,0,0,0.04)]` (very soft drop shadow), zero or ultra-thin borders.
*   **Buttons:** Pill-shaped (`rounded-full`), soft colored shadows on hover, smooth `transform-translate-y` lift on interaction.
*   **Inputs:** `rounded-xl`, soft gray borders that turn solid Violet on focus with a subtle focus ring.
*   **Status Badges:** Soft background fills with matching text colors (e.g., `bg-green-100 text-green-700`).

## 5. Interactivity & Motion
We will introduce `framer-motion` to the stack to provide:
*   Smooth fade-in page transitions.
*   Staggered loading for grids (e.g., Job Pool cards sliding up one by one).
*   Fluid layout animations when claiming or dropping jobs.
*   "Spring" physics rather than linear animations for a tactile, high-quality feel.

## 6. Structural Layouts
*   **Marketing Layout:** Floating header with glass-morphic blur, full-bleed sections, bento-box feature grids.
*   **App Layout (Authenticated):** Clean sidebar navigation, sticky header with breadcrumbs and user profile, max-width content area for focused reading and working.
